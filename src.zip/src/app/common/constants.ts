export const LOGO_URL =
  'https://www.olympusfintech.com/images/header-logo-olympus.png';

export const BASE_URL = 'http://10.6.6.101:3000';

import { Component, OnInit, ViewChild } from '@angular/core';
import { DxFormComponent } from 'devextreme-angular';

import { AuthService } from '../../services/auth.service';
import { LOGO_URL } from '../../common/constants';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent implements OnInit {
  @ViewChild(DxFormComponent, { static: false }) form!: DxFormComponent;
  formData = {
    newPassword: '',
    confirmPassword: '',
  };
  email = 'jsmith@abc-capital.com';
  passwordComparison = () => {
    return this.form.formData.newPassword;
  };
  buttonOptions = {
    useSubmitBehavior: true,
    text: 'Change Password',
    elementAttr: { class: 'w-100 mt-3' },
    type: 'default',
  };
  logoUrl = LOGO_URL;
  loading = false;
  message = '';

  constructor() {}

  ngOnInit(): void {}

  changePassword(event: Event): void {
    event.preventDefault();
    const { newPassword } = this.form.formData;
    this.message = 'Password changed successfully!';
    this.form.instance.resetValues();
  }
}

import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { DxFormComponent } from 'devextreme-angular';

import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DynamicFormComponent implements OnInit {
  @ViewChild(DxFormComponent, { static: false }) dxForm!: DxFormComponent;
  @Input() form!: any;
  formData: any[] = [];
  @Output() save = new EventEmitter();
  visible = false;
  loading = false;

  constructor(private dataService: DataService) {}

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    const { currentValue } = changes.form;
    this.visible = Boolean(currentValue.id);
    if (this.visible) {
      this.loading = true;
      this.dataService.formData(currentValue.id).subscribe(
        (res) => {
          this.loading = false;
          this.formData = res[0].data;
        },
        (err) => {
          this.loading = false;
        }
      );
    }
  }

  handleSave() {
    console.log(this.dxForm.formData);
  }
}
